from redbot.core.bot import Red
from redbot.core import commands
import asyncio
import discord

author = "geeter"
version = "0.0.1"


class Racemenu(commands.Cog):
    """My custom cog"""

    def __init__(self, bot:Red):
        self.bot = bot

    def check(self, reaction, user):
        return str(reaction.emoji) == '<a:leftracearrow:1081118540385484930>' or str(reaction.emoji) == '<a:rightracearrow:1081118440670122035>'

    @commands.command()
    async def racem(self, ctx):
        embed = discord.Embed(title="Choose your racer", color=0x00ff00)
        embed.set_image(url="https://imgur.com/gallery/CdeWPzq")
        msg = await ctx.send(embed=embed)
        # this posts an embed displaying the racer character image
        await msg.add_reaction("<a:leftracearrow:1081118540385484930>")
        await msg.add_reaction("<a:rightracearrow:1081118440670122035> ")
        # this reacts to the message above embed with the custom navigation emojis

        
        try:
            reaction, user = await self.bot.wait_for('reaction_add', timeout=60.0, check=check)
            # this awaits for the the user to react to one of the navigation emojis
        except asyncio.TimeoutError:
            await ctx.send('Timed out.')
            # this times out the racermenu if there is no reaction
        else:
            if str(reaction.emoji) == '<a:rightracearrow:1081118440670122035>':
                embed = discord.Embed(title="Racer 1", color=0x00ff00)
                embed.set_image(url="https://imgur.com/gallery/v7N7Q2y")
                await msg.edit(embed=embed)
                # if the user reacts with an emoji this is the new embed that will be displayed with a new racer image