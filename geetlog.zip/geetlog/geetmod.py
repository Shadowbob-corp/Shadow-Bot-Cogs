# Copyright (c) 2021 - Jojo#7791
# Licensed under MIT
from redbot.core import  commands, checks
from redbot.core.bot import Red
import discord

class Geetlog(commands.Cog):
    def __init__(self, bot: Red):
        self.bot = bot
        self.types = {0: "Mute", 1:"Kick", 2: "Ban", 3: "Move", 4: "Deafen"}

    
    def pfp(self, mem: discord.Member):
        user = mem
        if user.is_avatar_animated():
            url = user.avatar_url_as(format="gif")
        if not user.is_avatar_animated():
            url = user.avatar_url_as(static_format="png")
        print(url)
        return url

    @commands.command()
    @checks.mod_or_permissions(administrator=True)
    async def pull(self, ctx, member: discord.Member):
        role = member.guild.get_role(1037631864841711666)                        
        await member.add_roles(role, reason=f"Blacklist")
        await member.move_to(ctx.guild.get_channel(1049924751805648936))


    def past_tense(self, stri=""):
        if stri[-1] == 'e':
            return stri+"d"
        elif stri.lower() == "ban":
            return stri + "ned"
        else:
            return stri + "ed"

    async def post_to_logchannel( self,staff:discord.Member, member: discord.Member, message = "Geetlog", type=0):
        channel_id = 1047739355738943540        
        embed = discord.Embed(title="Member " + self.past_tense(self.types[type]), description=f"{member.mention} was {self.past_tense(self.types[type]).lower()}  by {staff.mention}", color=0xFF0000)
        embed.set_thumbnail(url=member.avatar_url)
        embed.set_author(name=staff.nick, icon_url=staff.avatar_url)        
        embed.add_field(name='Reason', value=message)
        await member.guild.get_channel(channel_id).send(embed=embed)
    
    
    @commands.Cog.listener()
    async def on_member_voice_state_update(self, guild: discord.Guild, user: discord.User):
        guild_id = str(guild.id)
        if self.config.has_option(guild_id, ""):
            async def post_to_logchannel( self,staff:discord.Member, member: discord.Member, message = "Geetlog", type=0)
        channel_id = 1047739355738943540        
        embed = discord.Embed(title="Member " + self.past_tense(self.types[type]), description=f"{member.mention} was {self.past_tense(self.types[type]).lower()}  by {staff.mention}", color=0xFF0000)
        embed.set_thumbnail(url=member.avatar_url)
        embed.set_author(name=staff.nick, icon_url=staff.avatar_url)        
        embed.add_field(name='Reason', value=message)
        await member.guild.get_channel(channel_id).send(embed=embed)

    print(f'{entry.user} did {entry.action} to {entry.target}')

    if before.mute != after.mute:
           await self.post_to_logchannel(staff,  member, message, type)
           discord.Embed(title="Member " + self.past_tense(self.types[type]), description=f"{member.mention} was {self.past_tense(self.types[type]).lower()}  by {staff.mention}", color=0xFF0000)

        
           
        