# Copyright (c) 2021 - Jojo#7791
# Licensed under MIT


from redbot.core import  commands, checks
from redbot.core.bot import Red
import discord
import asyncio

class Geetlog(commands.Cog):
    def __init__(self, bot: Red):
        self.bot = bot
        self.types = {0: "Mute", 1:"Kick", 2: "Ban", 3: "Move", 4: "Deafen"}

    
    def pfp(self, mem: discord.Member):
        user = mem
        if user.is_avatar_animated():
            url = user.avatar_url_as(format="gif")
        if not user.is_avatar_animated():
            url = user.avatar_url_as(static_format="png")
        print(url)
        return url

    @commands.command()
    @checks.mod_or_permissions(administrator=True)
    async def pull(self, ctx, member: discord.Member):
        role = member.guild.get_role(1037631864841711666)                        
        await member.add_roles(role, reason=f"Blacklist")
        await member.move_to(ctx.guild.get_channel(1049924751805648936))


    def past_tense(self, stri=""):
        if stri.lower() == "ban":
            return "Banned"
        if stri.lower() == "unban":
            return "Unbanned"
        if stri.lower() == "mute":
            return "Muted"
        if stri.lower() == "unmute":
            return "Unmuted"
        if stri.lower() == "kick":
            return "Kicked"
        if stri.lower() == "deafen":
            return "Deafened"
        if stri.lower() == "undeafen":
            return "Undeafened"

    async def post_to_logchannel( self,staff:discord.Member, member: discord.Member, message = "Geetlog", type=""):
        channel_id = 1047739355738943540        
        embed = discord.Embed(title="Member " + self.past_tense(type), description=f"{member.mention} was {self.past_tense(type)}  by {staff.mention}", color=0xFF0000)
        embed.set_thumbnail(url=member.avatar_url)
        embed.set_author(name=staff.nick, icon_url=staff.avatar_url)        
        embed.add_field(name='Reason', value=message)
        await member.guild.get_channel(channel_id).send(embed=embed)


    @commands.Cog.listener()    
    async def on_member_ban(self, guild, user):
        async for entry in user.guild.audit_logs(limit=100):
            print(f'{entry.user} did {entry.action} to {entry.target}')
        if entry.action is discord.AuditLogAction.ban:
            mes = "Ban"
        elif entry.action is discord.AuditLogAction.kick:
            mes = "Kick" 

    @commands.Cog.listener()    
    async def on_voice_state_update(self, member:discord.Member, before: discord.VoiceState, after: discord.VoiceState):
        asyncio.sleep(2)
        async for entry in member.guild.audit_logs(limit=100):
            if entry.target.id == member.id:
                print(f'{entry.user} did {entry.action} to {entry.target}')
                mes = ""
                n = -1
                if member.voice.mute != before.mute:
                    n = 0
                    if member.voice.mute: 
                        mes = "Mute"
                    else:
                        mes = "Unmute"
                elif after.deaf != before.deaf:
                    print('deaf')
                    n = 4
                    if member.voice.deaf:
                        mes = "Deafen"
                    else:
                        mes = "Undeafen"
                 
                if n != -1:
                    await self.post_to_logchannel(entry.user,  member, mes, mes)
                    break
                else:
                    await self.post_to_logchannel(entry.user,  member, "Error: Wrong Type", mes)
                    break